<?php

/**
 * Extension Manager/Repository config file for ext "erfa_secure".
 */
$EM_CONF[$_EXTKEY] = [
    'title' => 'Erfa Secure',
    'description' => 'Erfasecure Template',
    'category' => 'templates',
    'constraints' => [
        'depends' => [
            'typo3' => '9.5.0-9.5.99',
            'fluid_styled_content' => '9.5.0-9.5.99',
            'rte_ckeditor' => '9.5.0-9.5.99'
        ],
        'conflicts' => [
        ],
    ],
    'autoload' => [
        'psr-4' => [
            'ErfaSecure\\ErfaSecure\\' => 'Classes'
        ],
    ],
    'state' => 'stable',
    'uploadfolder' => 0,
    'createDirs' => '',
    'clearCacheOnLoad' => 1,
    'author' => 'Erhan Durucay',
    'author_email' => 'erhan@erfasecure.de',
    'author_company' => 'Erfa Secure',
    'version' => '1.0.0',
];
